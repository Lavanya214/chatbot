import React, { useState, useRef, useEffect } from "react";
import "./index.css";

export default function App() {
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState("");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const getTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("http://127.0.0.1:8000/upload_pdf", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setFileName(data.file_name);
      setMessages((prev) => [
        ...prev,
        { sender: "system", text: `✅ Uploaded ${data.file_name}`, time: getTime() },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "⚠️ Upload failed. Check backend.", time: getTime() },
      ]);
    }
  }

  async function handleAsk(e) {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { sender: "user", text: input, time: getTime() };
    setMessages((prev) => [...prev, userMessage]);

    try {
      const res = await fetch("http://127.0.0.1:8000/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: input, file_name: fileName }),
      });
      const data = await res.json();

      if (data.answer) {
        setMessages((prev) => [
          ...prev,
          { sender: "bot", text: data.answer, time: getTime() },
        ]);
      } else if (data.resources) {
        setMessages((prev) => [
          ...prev,
          { sender: "bot", text: "📚 Found resources:", time: getTime() },
          ...data.resources.map((r) => ({
            sender: "bot",
            text: `${r.keyword} → [Doc] ${r.doc_path} | [Video] ${r.video_link}`,
            time: getTime(),
          })),
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "⚠️ Failed to fetch answer. Check backend.", time: getTime() },
      ]);
    }

    setInput("");
  }

  return (
    <div className="container">
      <h1>🤖 AI PDF + DB Chatbot</h1>

      <form onSubmit={handleUpload} className="upload-form">
        <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files[0])} />
        <button type="submit">Upload</button>
      </form>

      <div className="chat-box">
        {messages.map((msg, i) => (
          <div key={i} className={`message ${msg.sender}`}>
            {msg.sender !== "user" && (
              <div className="avatar">🤖</div>
            )}
            <div className={`bubble ${msg.sender}`}>
              {msg.text}
              <div className="timestamp">{msg.time}</div>
            </div>
          </div>
        ))}
        <div ref={chatEndRef}></div>
      </div>

      <form onSubmit={handleAsk} className="input-form">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
